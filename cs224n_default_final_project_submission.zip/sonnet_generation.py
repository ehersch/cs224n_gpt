'''
Sonnet generation starter code.

Running:
  `python sonnet_generation.py --use_gpu`

trains your SonnetGPT model and writes the required submission files.

With LoRA (fewer params, often better for small datasets):
  `python sonnet_generation.py --use_gpu --use_lora`
'''

import argparse
import random
import torch

import numpy as np
import torch.nn.functional as F

from torch import nn
from torch.utils.data import DataLoader
from tqdm import tqdm
from transformers import GPT2Tokenizer
from einops import rearrange

from datasets import (
  SonnetsDataset,
)
from models.gpt2 import GPT2Model
from modules.lora import LoRALinear

from optimizer import AdamW

TQDM_DISABLE = False


# Fix the random seed.
def seed_everything(seed=11711):
  random.seed(seed)
  np.random.seed(seed)
  torch.manual_seed(seed)
  torch.cuda.manual_seed(seed)
  torch.cuda.manual_seed_all(seed)
  torch.backends.cudnn.benchmark = False
  torch.backends.cudnn.deterministic = True


def _apply_lora_to_gpt(gpt, rank, alpha):
  """Freeze base GPT and wrap target linear layers with LoRA."""
  for param in gpt.parameters():
    param.requires_grad = False

  for layer in gpt.gpt_layers:
    # Attention: Q, K, V
    layer.self_attention.query = LoRALinear(layer.self_attention.query, rank=rank, alpha=alpha)
    layer.self_attention.key = LoRALinear(layer.self_attention.key, rank=rank, alpha=alpha)
    layer.self_attention.value = LoRALinear(layer.self_attention.value, rank=rank, alpha=alpha)
    # Attention output
    layer.attention_dense = LoRALinear(layer.attention_dense, rank=rank, alpha=alpha)
    # MLP
    layer.interm_dense = LoRALinear(layer.interm_dense, rank=rank, alpha=alpha)
    layer.out_dense = LoRALinear(layer.out_dense, rank=rank, alpha=alpha)


class SonnetGPT(nn.Module):
  """Your GPT-2 Model designed for sonnet generation."""

  def __init__(self, args):
    super().__init__()
    self.gpt = GPT2Model.from_pretrained(model=args.model_size, d=args.d, l=args.l, num_heads=args.num_heads)
    self.tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
    self.tokenizer.pad_token = self.tokenizer.eos_token
    self.use_lora = getattr(args, 'use_lora', False)

    if self.use_lora:
      _apply_lora_to_gpt(self.gpt, rank=args.lora_rank, alpha=args.lora_alpha)
    else:
      for param in self.gpt.parameters():
        param.requires_grad = True

  def forward(self, input_ids, attention_mask):
    """
    This is similar to the forward for ParaphraseGPT, but we now want to produce a logit for each token in our sequence;
    not just the last token! This will allow our model to learn the natural language distribution that composes sonnets,
    not just the distribution over next tokens for the last token!
    """
    ### YOUR CODE HERE
    gpt_output = self.gpt(input_ids, attention_mask)
    last_hidden_state = gpt_output['last_hidden_state']
    logits = self.gpt.hidden_state_to_token(last_hidden_state)
    return logits


  def get_device(self):
    for param in self.gpt.parameters():
      return param.device

  # @torch.no_grad()
  # def generate(self, encoding, temperature=0.7, top_p=0.9, max_length=128):
  #   """
  #   Generates an original sonnet using top-p sampling and softmax temperature.

  #   TODO: this is probably not ideal. You can look at hugging face's model.generate(...) function for inspiration.
  #   In particular, generating multiple sequences and choosing the best with beam search is one avenue. Top_k is another;
  #   there are many.
  #   """
  #   token_ids = encoding.to(self.get_device())
  #   attention_mask = torch.ones(token_ids.shape, dtype=torch.int64).to(self.get_device())


  #   for _ in range(max_length):
  #     # Forward pass to get logits
  #     logits_sequence = self.forward(token_ids, attention_mask)
  #     logits_last_token = logits_sequence[:, -1, :] / temperature  # Apply temperature scaling

  #     # Convert logits to probabilities
  #     probs = torch.nn.functional.softmax(logits_last_token, dim=-1)

  #     # Top-p (nucleus) sampling
  #     sorted_probs, sorted_indices = torch.sort(probs, descending=True)
  #     cumulative_probs = torch.cumsum(sorted_probs, dim=-1)
  #     top_p_mask = cumulative_probs <= top_p
  #     top_p_mask[..., 1:] = top_p_mask[..., :-1].clone()  # Shift mask right for proper thresholding
  #     top_p_mask[..., 0] = True  # Always include the highest probability token
  #     filtered_probs = sorted_probs * top_p_mask  # Zero out unlikely tokens
  #     filtered_probs /= filtered_probs.sum(dim=-1, keepdim=True)  # Normalize probabilities

  #     # Sample from filtered distribution
  #     sampled_index = torch.multinomial(filtered_probs, 1)
  #     sampled_token = sorted_indices.gather(dim=-1, index=sampled_index)

  #     # Stop if end-of-sequence token is reached
  #     if sampled_token.item() == self.tokenizer.eos_token_id:
  #       break

  #     # Append sampled token
  #     token_ids = torch.cat([token_ids, sampled_token], dim=1)
  #     attention_mask = torch.cat(
  #       [attention_mask, torch.ones((1, 1), dtype=torch.int64).to(self.get_device())], dim=1
  #     )

  #   generated_output = self.tokenizer.decode(token_ids[0].cpu().numpy().tolist())[3:]
  #   return token_ids, generated_output

  @torch.no_grad()
  def generate(self, encoding, temperature=0.8, top_p=0.9, top_k=40, max_length=128):
    """
    Generates a sonnet using optimized Top-K and Top-P (Nucleus) sampling.
    """
    model_device = self.get_device()
    token_ids = encoding.to(model_device)
    if token_ids.dim() == 1:
        token_ids = token_ids.unsqueeze(0)
    current_ids = token_ids

    for _ in range(max_length):
        attention_mask = torch.ones_like(current_ids).to(model_device)
        logits = self.forward(current_ids, attention_mask)
        next_token_logits = logits[:, -1, :] / max(temperature, 1e-5)
        if top_k > 0:
            indices_to_remove = next_token_logits < torch.topk(next_token_logits, top_k)[0][..., -1, None]
            next_token_logits[indices_to_remove] = float('-inf')

        # Top-P (nucleus) sampling
        sorted_logits, sorted_indices = torch.sort(next_token_logits, descending=True)
        cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)

        sorted_indices_to_remove = cumulative_probs > top_p
        sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
        sorted_indices_to_remove[..., 0] = 0

        indices_to_remove = sorted_indices_to_remove.scatter(1, sorted_indices, sorted_indices_to_remove)
        next_token_logits[indices_to_remove] = float('-inf')

        probs = F.softmax(next_token_logits, dim=-1)
        next_token = torch.multinomial(probs, num_samples=1)

        current_ids = torch.cat([current_ids, next_token], dim=-1)
        
        if next_token.item() == self.tokenizer.eos_token_id:
            break

    generated_output = self.tokenizer.decode(current_ids[0], skip_special_tokens=True)
    return current_ids, generated_output

def save_model(model, optimizer, args, filepath):
  save_info = {
    'model': model.state_dict(),
    'optim': optimizer.state_dict(),
    'args': args,
    'system_rng': random.getstate(),
    'numpy_rng': np.random.get_state(),
    'torch_rng': torch.random.get_rng_state(),
  }

  torch.save(save_info, filepath)
  print(f"save the model to {filepath}")


def train(args):
  """Train GPT-2 for paraphrase detection on the Quora dataset."""
  device = torch.device('cuda') if args.use_gpu else torch.device('cpu')
  # Create the data and its corresponding datasets and dataloader.
  sonnet_dataset = SonnetsDataset(args.sonnet_path)
  sonnet_dataloader = DataLoader(sonnet_dataset, shuffle=True, batch_size=args.batch_size,
                                 collate_fn=sonnet_dataset.collate_fn)

  # Create the held-out dataset: these only have the first 3 lines. Your job is to fill in the rest!
  held_out_sonnet_dataset = SonnetsDataset(args.held_out_sonnet_path)

  args = add_arguments(args)
  model = SonnetGPT(args)
  model = model.to(device)

  lr = args.lr
  if args.use_lora:
    params = [p for p in model.parameters() if p.requires_grad]
    optimizer = AdamW(params, lr=lr)
    print(f"LoRA enabled: training {sum(p.numel() for p in params):,} parameters")
  else:
    optimizer = AdamW(model.parameters(), lr=lr)

  # Run for the specified number of epochs.
  for epoch in range(args.epochs):
    model.train()
    train_loss = 0
    num_batches = 0

    for batch in tqdm(sonnet_dataloader, desc=f'train-{epoch}', disable=TQDM_DISABLE):
      # Get the input and move it to the gpu (I do not recommend training this model on CPU).
      b_ids, b_mask = batch['token_ids'], batch['attention_mask']
      b_ids = b_ids.to(device)
      b_mask = b_mask.to(device)

      # Compute the loss, gradients, and update the model's parameters.
      optimizer.zero_grad()
      logits = model(b_ids, b_mask)
      logits = rearrange(logits[:, :-1].contiguous(), 'b t d -> (b t) d')  # Ignore the last prediction in the sequence.
      labels = b_ids[:, 1:].contiguous().flatten()  # Ignore the first token to compose the labels.
      loss = F.cross_entropy(logits, labels, reduction='mean')
      loss.backward()
      optimizer.step()

      train_loss += loss.item()
      num_batches += 1

    train_loss = train_loss / num_batches
    print(f"Epoch {epoch}: train loss :: {train_loss :.3f}.")
    print('Generating several output sonnets...')
    model.eval()
    for batch in held_out_sonnet_dataset:
      encoding = model.tokenizer(batch[1], return_tensors='pt', padding=True, truncation=True).to(device)
      output = model.generate(encoding['input_ids'], temperature=args.temperature, top_p=args.top_p)
      print(f'{batch[1]}{output[1]}\n\n')

    # TODO: consider a stopping condition to prevent overfitting on the small dataset of sonnets.
    save_model(model, optimizer, args, f'{epoch}_{args.filepath}')


@torch.no_grad()
def generate_submission_sonnets(args):
  device = torch.device('cuda') if args.use_gpu else torch.device('cpu')
  saved = torch.load(f'{args.epochs-1}_{args.filepath}', weights_only=False)

  model = SonnetGPT(saved['args'])
  model.load_state_dict(saved['model'])
  model = model.to(device)
  model.eval()

  # Create the held-out dataset: these only have the first 3 lines. Your job is to fill in the rest!
  held_out_sonnet_dataset = SonnetsDataset(args.held_out_sonnet_path)

  generated_sonnets = []
  for batch in held_out_sonnet_dataset:
    sonnet_id = batch[0]
    encoding = model.tokenizer(batch[1], return_tensors='pt', padding=False, truncation=True).to(device)
    output = model.generate(encoding['input_ids'], temperature=args.temperature, top_p=args.top_p)[0][0]
    decoded_output = model.tokenizer.decode(output)
    full_sonnet = f'{decoded_output}\n\n'
    generated_sonnets.append((sonnet_id, full_sonnet))

    print(f'{decoded_output}\n\n')

  with open(args.sonnet_out, "w+") as f:
    f.write(f"--Generated Sonnets-- \n\n")
    for sonnet in generated_sonnets:
      f.write(f"\n{sonnet[0]}\n")
      f.write(sonnet[1])


def get_args():
  parser = argparse.ArgumentParser()

  parser.add_argument("--sonnet_path", type=str, default="data/sonnets.txt")
  parser.add_argument("--held_out_sonnet_path", type=str, default="data/sonnets_held_out.txt")
  parser.add_argument("--sonnet_out", type=str, default="predictions/generated_sonnets.txt")

  parser.add_argument("--seed", type=int, default=11711)
  parser.add_argument("--epochs", type=int, default=10)
  parser.add_argument("--use_gpu", action='store_true')

  # Generation parameters.
  parser.add_argument("--temperature", type=float, help="softmax temperature.", default=1.2)
  parser.add_argument("--top_p", type=float, help="Cumulative probability distribution for nucleus sampling.",
                      default=0.9)

  parser.add_argument("--batch_size", help='The training batch size.', type=int, default=8)
  parser.add_argument("--lr", type=float, help="learning rate", default=1e-5)
  parser.add_argument("--model_size", type=str, help="The model size as specified on hugging face.",
                      choices=['gpt2', 'gpt2-medium', 'gpt2-large', 'gpt2-xl'], default='gpt2')

  # LoRA (Low-Rank Adaptation) - fewer trainable params, often better for small datasets
  parser.add_argument("--use_lora", action='store_true', help="Use LoRA instead of full fine-tuning")
  parser.add_argument("--lora_rank", type=int, default=8, help="LoRA rank (typical: 4, 8, 16)")
  parser.add_argument("--lora_alpha", type=float, default=16.0, help="LoRA scaling (2*rank)")

  args = parser.parse_args()
  return args


def add_arguments(args):
  """Add arguments that are deterministic on model size."""
  if args.model_size == 'gpt2':
    args.d = 768
    args.l = 12
    args.num_heads = 12
  elif args.model_size == 'gpt2-medium':
    args.d = 1024
    args.l = 24
    args.num_heads = 16
  elif args.model_size == 'gpt2-large':
    args.d = 1280
    args.l = 36
    args.num_heads = 20
  else:
    raise Exception(f'{args.model_size} is not supported.')
  return args


if __name__ == "__main__":
  args = get_args()
  args.filepath = f'{args.epochs}-{args.lr}-sonnet.pt'  # Save path.
  seed_everything(args.seed)  # Fix the seed for reproducibility.
  train(args)
  generate_submission_sonnets(args)